
public class LuhnApp {


	/**
	 * @author tLutkavage
	 * @since February 1, 2018
	 * @param args Command Line parameters
	 * @param arg[0] Name of function to run
	 * @param arg[1] First parameter to functionName
	 * @param arg[2] Second parameter to functionName	
	 * 
	 *  Environment:
	 *  Developed on a Windows 7 machine
	 *  Java 9 
	 *  Gradle 4.5
	 *  Eclipse Oxygen 2 Release 4.7.2
	 *   
	 * Note:This application was written in Eclipse using its Run Configurations -> Arguments tab to pass parameters.
	 * 
	 * The application allows the user to run one of three functions available to test for Luhn numbers.
	 * 
	 * The three functions are:
	 * 		isValidLuhn(cardNumber)
	 * 		generateCheckDigit(cardNumber)
	 * 		countRange(startRange, endRange)
	 * 
	 * Pass the parameters as <functionName><space><parameter1><space><parameter2 (as needed)>
	 * 
	 * No parameters at all causes the application to run all three functions with hardcoded values.
	 * 
	 * The functions are defined in the Luhn class.
	 **/
	public static void main(String[] args) {
		
		Luhn luhn = new Luhn();
		 
		String cardNumber="4485120987343235";
		// cardNumber="4485120987343235"; // Numbers courtesy of https://www.freeformatter.com/credit-card-number-generator-validator.html
		// cardNumber="5131293370559603";
		// cardNumber="30441546343682";
		// cardNumber="340379841193664";
		// cardNumber="qwerty";
		// cardNumber = "-12";
		// cardNumber = "0";
		//cardNumber="";
		
		String truncatedNumber="3044154634368";
		//truncatedNumber="513129337055960";
		//truncatedNumber="4992739871";
		
		String startRange = "4485120987343235";
		String endRange   = "4485120987343335";
		
		int nArgs = args.length;
		if (nArgs == 0) {
			System.out.println("No arguments provided.");
			runDefaultTests(luhn, cardNumber, truncatedNumber, startRange, endRange); 
		} else {
			for(String arg: args)   System.out.println("Argument = " + arg );  
			if(args[0].toLowerCase().equals("isvalidluhn"))  {
				if(nArgs != 2) System.out.println("Missing card number argument for isValidLuhn."); 
				else  runIsValidLuhn(luhn, args[1]);
			} else if(args[0].toLowerCase().equals("generatecheckdigit")) {
				if(nArgs != 2) System.out.println("Missing card number argument for generateCheckDigit."); 
				else  runGenerateCheckDigit(luhn, args[1]);
			} else if(args[0].toLowerCase().equals("countrange")){
				if(nArgs != 3) System.out.println("Missing card number argument(s) for countRange."); 
				else  runCountRange(luhn, args[1], args[2]);
			} else {
				System.out.println("Unrecognized command \""+args[0]+"\". Running default tests...\n");
				runDefaultTests(luhn, cardNumber, truncatedNumber, startRange, endRange); 
			}
			
		}
 	}
	
	private static void runDefaultTests(Luhn luhn, String cardNumber, String truncatedNumber, String startRange, String endRange) {
 		runIsValidLuhn(luhn,cardNumber);
		runGenerateCheckDigit(luhn, truncatedNumber);		 
		runCountRange(luhn, startRange, endRange);	
	}
	
	private static void runIsValidLuhn (Luhn luhn, String cardNumber) {
		try {
			boolean isValid = luhn.isValidLuhn(cardNumber); 
			System.out.println("The number "+cardNumber+ " is " + (isValid ? "" : "not ") +"a valid Luhn number.");
		} catch (NumberFormatException e){			
			System.out.println(e.getMessage());
		}	
	}
	
	
	private static void runGenerateCheckDigit (Luhn luhn, String truncatedNumber) {
		try {
			String checkDigit=luhn.generateCheckDigit(truncatedNumber);
			System.out.println("The check digit for " + truncatedNumber + " is " + checkDigit+".");
		}
		catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}
	}
	
	private static void runCountRange(Luhn luhn, String startRange, String endRange) {
		try {
			int nValidNumbers=luhn.countRange(startRange, endRange);
			System.out.println("The number of valid Luhn numbers between "+ startRange+ " and "+ endRange + " is "+ nValidNumbers+".");
		}
		catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}
	}	
	
	
}
