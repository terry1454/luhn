import java.util.stream.LongStream;

public class Luhn {
	
/* Luhn algorithm information gleaned from:
 * http://www.comparecards.com/blog/understanding-the-luhn-algorithm/
 * https://support.symantec.com/en_US/article.TECH221769.html
 * https://www.geeksforgeeks.org/luhn-algorithm/
 * https://stackoverflow.com/questions/20725761/validate-credit-card-number-using-luhn-algorithm
 * and various other locations.
 */
	
	
	
/**********************************************************************************************
* Accepts a card number and determines if the card number is a valid number with
* respect to the Luhn algorithm.
* @param cardNumber the card number
* @return true if the card number is valid according to the Luhn algorithm, false if not
*/
	public boolean isValidLuhn(String cardNumber) {
		 
		validateCardNumber(cardNumber);
	 	
		int sum = 0;
		int nDigits = cardNumber.length();
		int checkDigit = Integer.parseInt(cardNumber.substring(nDigits-1));
		sum=checkDigit;
		sum+=getTruncatedSum(cardNumber.substring(0,nDigits-1));
	
 		return ((sum % 10)==0);
	}
	
/************************************************************************************************
* Accepts a partial card number (excluding the last digit) and generates the
* appropriate Luhn check digit for the number.
* @param cardNumber the card number (not including a check digit)
* @return the check digit
* 
* It is assumed the cardNumber provided is a valid Luhn number without its final digit.
*/
	public String generateCheckDigit(String cardNumber) {
		
		validateCardNumber(cardNumber);
		
		int sum = getTruncatedSum(cardNumber);
		Integer checkDigit = (10 -(sum % 10)) ;
		return checkDigit.toString();
	}
	
	
/*************************************************************************************************
* Accepts two card numbers representing the starting and ending numbers of a
* range of card numbers and counts the number of valid Luhn card numbers 
* that exist in the range, inclusive.
* @param startRange the starting card number of the range
* @param endRange the ending card number of the range
* @return the number of valid Luhn card numbers in the range, inclusive
*/
	public int countRange(String startRange, String endRange) {
 		int nValidNumbers = 0;
	
		validateCardNumber(startRange);
		validateCardNumber(endRange);
		
		Long firstNumber = Long.parseLong(startRange);
		Long lastNumber = Long.parseLong(endRange);
		Long temp = 0L; 
		if (lastNumber < firstNumber) { 
			temp = lastNumber; lastNumber= firstNumber; firstNumber=temp; 			
		}

		/* Note: I would prefer to define nValidNumbers as a long, 
		 * but since the definition of the function in the exercise
		 * description was to return an int, I defined it as an int.
		 */
		nValidNumbers = (int) LongStream.rangeClosed(firstNumber, lastNumber).filter(l -> isValidLuhn(String.valueOf(l))).count();
		
		/*for(long l=firstNumber; l<=lastNumber; l++) {
			if(isValidLuhn(Long.toString(l)))  {  nValidNumbers++; }
 		}*/
		
		return nValidNumbers;
	}
	
/** Accepts a string of numbers whose rightmost digit is assumed to have been stripped
 * and generates the "Luhn" sum: the sum of the numbers per the Luhn algorithm less the
 * checkDigit.
 * The purpose of this function is solely to eliminate code repetition. The result of the 
 * for loop is used by both isValidLuhn() and generateCheckDigit()
 * @param numberStr The number string to validate
 * @return the sum of the numbers
 */
	private int getTruncatedSum(String numberStr) {
		String [] digitArray = numberStr.split("(?!^)");
		int nDigits = numberStr.length();
		int parity = ((nDigits-1) % 2); 	// parity helps us understand when we need to just sum the
											// individual digit and when we need to "split and sum" 
		int digit = 0;
		int sum =0;
		
		for (int i = nDigits-1; i >-1; i--) {
			digit=Integer.parseInt(digitArray[i]);		
			if((i%2) == parity) { 			// if the "oddness/eveness" of the place in the digit (1st place vs 2nd place)
											// matches the oddness/eveness of the number of digits in our number
											// then double the digit and check if the resulting value
											// has > 1 place. If it does, then reduce the number to a single digit.
											// Subtracting 9 is the equivalent of summing the digits of the value, 
											// e.g., digit *= 2 = 16. (1 + 6 = 7)  == (16 - 9 = 7)
				digit *= 2;  
				if (digit > 9) { digit = digit - 9; }
			} 		
			sum += digit;
		}			
	
		return sum;
	}
	
	/*** Let us do some basic number validation so we avoid the possibility
	 * of complete embarrassment...
	 * 
	 * @param cardNumber The card number to validate
	 * @throws NumberFormatException
	 */
	private void validateCardNumber(String cardNumber) throws NumberFormatException {
		long l = 0L;
	 	try {
			l = Long.parseLong(cardNumber);
		} catch (NumberFormatException e) {
			throw new NumberFormatException("The card number " + cardNumber +" does not convert properly to a number.");
		}
		if(l < 0) 
			throw new NumberFormatException("Card numbers cannot be negative.");
	 
		
		/* Since all parameter names imply a credit card number, we check for the standard length.
		 * The functions all work with any length number. 
		 * 
		 * But then...
		 * Decided allowing lengths other than 16 was more interesting and since it 
		 * was not explicitly stated that all provided numbers would only have 16 characters, 
		 * we allow a greater range than a more restricted one.
		
		if(cardNumber.length() != 16)  
			throw new NumberFormatException(message 
										+ "Card numbers are expected to have length 16. The length of your card number is "+cardNumber.length()+".");
		 */
		return;
	}
}
