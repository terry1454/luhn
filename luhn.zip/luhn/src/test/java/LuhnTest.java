import org.junit.*;
import org.junit.rules.ExpectedException;

public class LuhnTest {

	Luhn luhn = new Luhn(); 
	@Rule
	public ExpectedException exception = ExpectedException.none();
	
	/**** isValidLuhn() *******************************************************************************/
	@Test
	public void isValidLuhn_LuhnNumber() {
		boolean isValid = false;
		isValid = this.luhn.isValidLuhn("4485120987343235");
		 Assert.assertTrue("isValidLuhn should return true when provided a Luhn number.",isValid);
	}
 
	@Test
	public void isValidLuhn_NotLuhnNumber()   {
		boolean isValid = true;
		isValid = this.luhn.isValidLuhn("12345");
		Assert.assertFalse("isValidLuhn should return false when provided a non-Luhn number.",isValid);
	}
	
	@Test
	public void isValidLuhn_NonNumberString()  {
		boolean isValid = true;
		String cardNumber="good morning";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + cardNumber +" does not convert properly to a number.");
		isValid = this.luhn.isValidLuhn(cardNumber);
 	}
	
	@Test
	public void isValidLuhn_NegativeLuhnNumber() {
		boolean isValid = false;
		String cardNumber="-4485120987343235";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("Card numbers cannot be negative.");
		isValid = this.luhn.isValidLuhn(cardNumber);
 	}

	@Test
	public void isValidLuhn_EmptyString() {
		boolean isValid = false;
		String cardNumber="";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + cardNumber +" does not convert properly to a number.");
		isValid = this.luhn.isValidLuhn(cardNumber);
 	}
	/**** generateCheckDigit() *******************************************************************************/

	@Test
	public void generateCheckDigit_LuhnNumber() {
		String checkDigit = "-1";
		String cardNumber = "448512098734323"; // 4485120987343235 is the original number
		checkDigit = this.luhn.generateCheckDigit(cardNumber);
		Assert.assertEquals(checkDigit,"5");
	}
 
 
	@Test
	public void generateCheckDigit_NonNumberString()  {
		String checkDigit = "-1";
		String cardNumber="not a number";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + cardNumber +" does not convert properly to a number.");
		checkDigit = this.luhn.generateCheckDigit(cardNumber);
 	}
	
	@Test
	public void generateCheckDigit_NegativeLuhnNumber() {
		String checkDigit = "-1";
		String cardNumber = "-448512098734323"; // 4485120987343235 is the original number
		exception.expect(NumberFormatException.class);
		exception.expectMessage("Card numbers cannot be negative.");
		checkDigit = this.luhn.generateCheckDigit(cardNumber);
 	}

	@Test
	public void generateCheckDigit_EmptyString() {
		String checkDigit = "-1";
		String cardNumber="";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + cardNumber +" does not convert properly to a number.");
		checkDigit = this.luhn.generateCheckDigit(cardNumber);
 	}
	
	/**** countRange() *******************************************************************************/
	@Test
	public void countRange_IdenticalLuhnNumbers() {
		int nValidNumbers = -1;
		String startRange = "4485120987343235";  
		String endRange = "4485120987343235"; 
		nValidNumbers = this.luhn.countRange(startRange,endRange);
		Assert.assertEquals(nValidNumbers,1);
	}
	@Test
	public void countRange_LuhnNumbers() {
		int nValidNumbers = -1;
		String startRange = "4485120987343235";  
		String endRange = "4485120987344235"; // ++ 1000
		nValidNumbers = this.luhn.countRange(startRange,endRange);
		Assert.assertEquals(nValidNumbers,101);
	}
  
	@Test
	public void countRange_NonNumberStartString()  {
		int nValidNumbers = -1;
		String startRange = "hello luhn";
		String endRange = "4485120987343235";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + startRange +" does not convert properly to a number.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}
	@Test
	public void countRange_NonNumberEndString()  {
		int nValidNumbers = -1;
		String startRange = "4485120987343235";
		String endRange = "goodbye luhn";
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + endRange +" does not convert properly to a number.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}
	
	@Test
	public void countRange_NegativeStartLuhnNumber() {
		int nValidNumbers = -1;
		String startRange = "-4485120987343235";  
		String endRange = "4485120987343235";  
		exception.expect(NumberFormatException.class);
		exception.expectMessage("Card numbers cannot be negative.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}
	@Test
	public void countRange_NegativeEndLuhnNumber() {
		int nValidNumbers = -1;
		String startRange = "4485120987343235";  
		String endRange = "-4485120987343235";  
		exception.expect(NumberFormatException.class);
		exception.expectMessage("Card numbers cannot be negative.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}

	@Test
	public void countRange_EmptyStartString() {
		int nValidNumbers = -1;
		String startRange = "";  
		String endRange = "4485120987343235";  
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + startRange +" does not convert properly to a number.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}
	@Test
	public void countRange_EmptyEndString() {
		int nValidNumbers = -1;
		String startRange = "4485120987343235";  
		String endRange = "";  
		exception.expect(NumberFormatException.class);
		exception.expectMessage("The card number " + endRange +" does not convert properly to a number.");
		nValidNumbers = this.luhn.countRange(startRange,endRange);
 	}

}
